import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import AuthGuard from '@/components/AuthGuard';
import TopBar from '@/components/TopBar';
import BottomNav from '@/components/BottomNav';

import { ToastProvider } from '@/components/Toast';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
// ... existing code ...
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.variable} font-sans bg-transparent text-foreground antialiased`}>
        <AuthGuard>
          <ToastProvider>
            <div className="min-h-screen pb-20 pt-16 md:pt-20 md:pb-0 max-w-7xl mx-auto relative min-h-screen md:flex md:flex-col">
              <TopBar />
              <div className="flex-1 md:flex md:justify-center">
                <main className="h-full w-full md:max-w-2xl overflow-y-auto scrollbar-hide min-h-screen">
                  {children}
                </main>
              </div>
              <BottomNav />
            </div>
          </ToastProvider>
        </AuthGuard>
      </body>
    </html>
  );
}
