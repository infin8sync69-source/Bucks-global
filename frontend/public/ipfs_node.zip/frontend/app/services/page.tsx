"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { FaCloudArrowUp, FaFile, FaCheck, FaRocket, FaTerminal } from 'react-icons/fa6';
import { uploadFile } from '@/lib/api';
import StarField from '@/components/StarField';

export default function Upload() {
    const router = useRouter();
    const [file, setFile] = useState<File | null>(null);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [isUploading, setIsUploading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
            setError('');
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!file || !title) {
            setError('Please select a file and provide a title.');
            return;
        }

        setIsUploading(true);
        setError('');

        const formData = new FormData();
        formData.append('file', file);
        formData.append('title', title);
        formData.append('description', description);

        try {
            await uploadFile(formData);
            setSuccess(true);
            setTimeout(() => {
                router.push('/feed');
            }, 1500);
        } catch (err) {
            console.error('Upload failed', err);
            setError('Failed to upload file. Please try again.');
            setIsUploading(false);
        }
    };

    if (success) {
        return (
            <div className="relative min-h-screen flex items-center justify-center p-6 overflow-hidden">
                <StarField />
                <div className="relative z-10 text-center animate-in fade-in zoom-in-95 duration-500">
                    <div className="w-24 h-24 bg-primary/20 backdrop-blur-2xl rounded-3xl flex items-center justify-center mb-8 mx-auto border border-primary/30 shadow-[0_0_50px_rgba(168,85,247,0.4)]">
                        <FaRocket className="text-4xl text-primary animate-bounce" />
                    </div>
                    <h2 className="text-3xl font-black text-white mb-2 tracking-tight">MISSION SUCCESSFUL</h2>
                    <p className="text-primary font-bold text-sm tracking-widest uppercase">Content Injected into Swarm</p>
                    <div className="mt-8 flex items-center justify-center space-x-2 text-white/40 text-[10px] font-mono">
                        <FaTerminal />
                        <span>REDIRECTING_TO_FEED...</span>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="relative min-h-screen w-full overflow-hidden bg-black pb-32">
            <StarField />

            {/* Background Accents */}
            <div className="fixed top-[-10%] right-[-10%] w-[500px] h-[500px] bg-primary/10 blur-[120px] rounded-full pointer-events-none" />
            <div className="fixed bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-blue-500/10 blur-[120px] rounded-full pointer-events-none" />

            <div className="relative z-10 max-w-2xl mx-auto px-6 pt-12">
                <div className="text-center mb-12 animate-in fade-in slide-in-from-top-4 duration-700">
                    <div className="inline-flex items-center space-x-2 bg-primary/10 border border-primary/20 px-3 py-1 rounded-full text-primary text-[10px] font-bold tracking-widest uppercase mb-4">
                        <FaRocket className="animate-pulse" />
                        <span>Space Port 01</span>
                    </div>
                    <h1 className="text-4xl font-black text-white tracking-tighter mb-2">UPLOAD CONTENT</h1>
                    <p className="text-white/50 text-sm">Decentralize your media across the global swarm</p>
                </div>

                {error && (
                    <div className="bg-red-500/10 border border-red-500/50 text-red-400 text-xs font-bold p-4 rounded-2xl mb-8 animate-in fade-in zoom-in-95 backdrop-blur-md">
                        {error}
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-8">
                    {/* File Port */}
                    <div className="group relative bg-white/5 backdrop-blur-xl border-2 border-dashed border-white/10 rounded-3xl p-12 text-center transition-all hover:border-primary/50 hover:bg-white/10 cursor-pointer overflow-hidden shadow-2xl">
                        <input
                            type="file"
                            accept="image/*,video/*,application/pdf"
                            onChange={handleFileChange}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                        />

                        {/* Interactive BG effect */}
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

                        {file ? (
                            <div className="relative z-10 flex flex-col items-center">
                                <div className="w-20 h-20 bg-primary/20 rounded-2xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110 duration-500">
                                    <FaFile className="text-3xl text-primary" />
                                </div>
                                <span className="font-bold text-white text-lg truncate max-w-full px-4 mb-1">
                                    {file.name}
                                </span>
                                <span className="text-[10px] font-mono text-white/40 tracking-widest uppercase">
                                    {(file.size / 1024 / 1024).toFixed(2)} MB • READY FOR LAUNCH
                                </span>
                            </div>
                        ) : (
                            <div className="relative z-10 flex flex-col items-center">
                                <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mb-6 transition-all group-hover:bg-primary/20 group-hover:shadow-[0_0_40px_rgba(168,85,247,0.3)]">
                                    <FaCloudArrowUp className="text-4xl text-white group-hover:text-primary transition-colors" />
                                </div>
                                <h3 className="text-white font-bold text-lg mb-1">Select Media or Docs</h3>
                                <p className="text-white/30 text-xs">Drag and drop into the docking port</p>
                            </div>
                        )}
                    </div>

                    {/* Metadata Section */}
                    <div className="grid grid-cols-1 gap-6 bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl shadow-2xl">
                        <div>
                            <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-3 ml-1">
                                Mission Title
                            </label>
                            <input
                                type="text"
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                placeholder="Enter operation name..."
                                className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-4 text-white text-sm focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/10 transition-all placeholder:text-white/20"
                            />
                        </div>

                        <div>
                            <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-3 ml-1">
                                Log Description
                            </label>
                            <textarea
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                placeholder="What's this about?"
                                rows={2}
                                className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-4 text-white text-sm focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/10 transition-all placeholder:text-white/20 resize-none"
                            />
                        </div>
                    </div>

                    {/* Launch Button */}
                    <button
                        type="submit"
                        disabled={isUploading}
                        className={`w-full relative group overflow-hidden py-5 rounded-3xl font-black text-sm tracking-[0.3em] uppercase transition-all active:scale-[0.98] ${isUploading
                            ? 'bg-gray-800 text-white/20 cursor-not-allowed'
                            : 'bg-primary text-white shadow-[0_10px_40px_rgba(168,85,247,0.3)] hover:shadow-[0_15px_60px_rgba(168,85,247,0.5)]'
                            }`}
                    >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                        {isUploading ? (
                            <span className="flex items-center justify-center space-x-3">
                                <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                                <span>INJECTING_CONTENT...</span>
                            </span>
                        ) : (
                            <span className="flex items-center justify-center space-x-3">
                                <FaRocket className="text-xs" />
                                <span>Initiate Launch</span>
                            </span>
                        )}
                    </button>
                </form>
            </div>
        </div>
    );
}
