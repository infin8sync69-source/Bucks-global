"use client";

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { FaUser, FaShare, FaPen, FaMessage, FaShieldHalved, FaArrowsRotate, FaEllipsisVertical } from 'react-icons/fa6';
import { fetchProfile, fetchLibrary, UserProfile, LibraryItem, fetchAllInteractions, Interaction, updateProfile } from '@/lib/api';
import PostCard from '@/components/PostCard';
import GuardianManager from '@/components/GuardianManager';
import Avatar from '@/components/Avatar';
import { useToast } from '@/components/Toast';

import { useRouter } from 'next/navigation';

type Tab = 'feed' | 'media' | 'files' | 'tweets' | 'syncs' | 'contacts';
type MediaSubTab = 'all' | 'images' | 'videos';

export default function Account() {
    const router = useRouter();
    const { showToast } = useToast();
    const [profile, setProfile] = useState<UserProfile | null>(null);
    const [activeTab, setActiveTab] = useState<Tab>('feed');
    const [mediaSubTab, setMediaSubTab] = useState<MediaSubTab>('all');
    const [posts, setPosts] = useState<LibraryItem[]>([]);
    const [interactions, setInteractions] = useState<Record<string, Interaction>>({});
    const [showGuardianManager, setShowGuardianManager] = useState(false);
    const [guardians, setGuardians] = useState<string[]>([]);
    const [following, setFollowing] = useState<any[]>([]);
    const [isSyncing, setIsSyncing] = useState(false);
    const [showDropdown, setShowDropdown] = useState(false);

    // Edit states
    const [editName, setEditName] = useState('');
    const [editBio, setEditBio] = useState('');
    const [editHandle, setEditHandle] = useState('');
    const [editLocation, setEditLocation] = useState('');
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        fetchProfile().then(p => {
            setProfile(p);
            setEditName(p.username);
            setEditBio(p.bio);
            setEditHandle(p.handle || '');
            setEditLocation(p.location || '');
        }).catch(console.error);
        fetchLibrary().then(setPosts).catch(console.error);
        fetchAllInteractions().then(setInteractions).catch(console.error);
        fetch('http://localhost:8000/api/guardians')
            .then(res => res.json())
            .then(data => setGuardians(data.guardians || []))
            .catch(console.error);
        fetch('http://localhost:8000/api/following')
            .then(res => res.json())
            .then(data => setFollowing(data.following || []))
            .catch(console.error);
    }, []);

    if (!profile) return null;

    // Filter content based on tabs
    const mediaPosts = posts.filter(p => {
        const isMedia = p.filename && (p.filename.toLowerCase().endsWith('.jpg') || p.filename.toLowerCase().endsWith('.png') || p.filename.toLowerCase().endsWith('.jpeg') || p.filename.toLowerCase().endsWith('.mp4'));
        if (!isMedia) return false;

        if (mediaSubTab === 'images') {
            return p.filename.toLowerCase().match(/\.(jpg|jpeg|png|gif|webp)$/i);
        }
        if (mediaSubTab === 'videos') {
            return p.filename.toLowerCase().endsWith('.mp4');
        }
        return true;
    });
    const filePosts = posts.filter(p => p.type === 'file' && !mediaPosts.includes(p));

    return (
        <div className="bg-white min-h-screen pb-20">
            {/* Banner & Header */}
            <div className="relative">
                <div className="h-32 md:h-48 bg-gray-200 w-full overflow-hidden">
                    <img src={profile.banner || "https://images.unsplash.com/photo-1451187580459-43490279c0fa"} alt="Banner" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-12 left-4">
                    <Avatar
                        src={profile.avatar}
                        seed={profile.peer_id}
                        size="xl"
                        className="!w-24 !h-24 md:!w-32 md:!h-32 border-4 border-white shadow-xl hover:scale-105 transition-transform duration-500"
                    />
                </div>
            </div>

            {/* Profile Info */}
            <div className="pt-14 px-4">
                <div className="flex justify-between items-start">
                    <div className="flex-1">
                        <h1 className="text-2xl font-bold text-foreground">{profile.username}</h1>
                        <p className="text-secondary text-sm">{profile.handle || `@${profile.username.toLowerCase().replace(' ', '_')}`}</p>
                        <div className="flex items-center text-xs text-secondary mt-1">
                            <span className="mr-1">📍</span> {profile.location || 'Bengaluru, KA'}
                        </div>
                    </div>
                    <div className="flex items-center space-x-2">
                        <button
                            onClick={() => router.push('/settings')}
                            className="bg-primary text-white px-4 py-2 rounded-full text-sm font-bold shadow-md hover:bg-purple-700 transition-all active:scale-95 flex items-center gap-2"
                        >
                            <FaPen className="text-xs" /> Edit
                        </button>
                        <div className="relative">
                            <button
                                onClick={() => setShowDropdown(!showDropdown)}
                                className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors text-secondary"
                            >
                                <FaEllipsisVertical />
                            </button>
                            {showDropdown && (
                                <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-50 animate-in fade-in zoom-in-95 duration-200">
                                    <button
                                        onClick={() => {
                                            navigator.clipboard.writeText(window.location.href);
                                            showToast('Profile link copied to clipboard!', 'success');
                                            setShowDropdown(false);
                                        }}
                                        className="w-full text-left px-4 py-3 text-sm hover:bg-gray-50 flex items-center gap-3 text-foreground"
                                    >
                                        <FaShare className="text-primary" /> Share Profile
                                    </button>
                                    <button
                                        onClick={() => setShowDropdown(false)}
                                        className="w-full text-left px-4 py-3 text-sm hover:bg-gray-50 flex items-center gap-3 text-foreground border-t border-gray-50"
                                    >
                                        <FaUser className="text-primary" /> View Details
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Stats */}
                <div className="flex space-x-6 mt-4 mb-4">
                    <button onClick={() => setActiveTab('syncs')} className="text-sm hover:opacity-70 transition-opacity">
                        <span className="font-bold text-foreground">
                            {profile.stats.syncs}
                        </span> <span className="text-secondary">syncs</span>
                    </button>
                    <button onClick={() => setActiveTab('contacts')} className="text-sm hover:opacity-70 transition-opacity">
                        <span className="font-bold text-foreground">
                            {profile.stats.contacts}
                        </span> <span className="text-secondary">contacts</span>
                    </button>
                </div>

                {/* Bio & Tags */}
                <p className="text-sm text-foreground mb-3 leading-relaxed">
                    {profile.bio}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                    {(profile.tags || []).map((tag, i) => (
                        <span key={i} className="bg-purple-100 text-primary text-xs px-2 py-1 rounded-full font-medium">
                            {tag}
                        </span>
                    ))}
                </div>

                {/* Peer ID Display */}
                {profile.peer_id && (
                    <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-xl mb-4 border border-purple-200">
                        <div className="flex items-center justify-between">
                            <div className="flex-1 min-w-0">
                                <p className="text-xs font-medium text-gray-600 mb-1">Your IPFS Peer ID</p>
                                <p className="text-sm font-mono text-gray-800 truncate">
                                    {profile.peer_id}
                                </p>
                            </div>
                            <button
                                onClick={() => {
                                    if (profile.peer_id) {
                                        navigator.clipboard.writeText(profile.peer_id);
                                        alert('Peer ID copied to clipboard!');
                                    }
                                }}
                                className="ml-3 px-3 py-2 bg-white text-primary rounded-lg text-xs font-medium hover:bg-gray-50 transition-colors border border-purple-300"
                            >
                                Copy
                            </button>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                            Share this ID with others so they can follow you and sync your content
                        </p>
                    </div>
                )}

                {/* Account Security Section */}
                <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm mb-6 mt-6">
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-purple-50 text-primary rounded-xl flex items-center justify-center text-xl">
                                <FaShieldHalved />
                            </div>
                            <div>
                                <h2 className="font-bold text-lg">Account Security</h2>
                                <p className="text-secondary text-xs">{guardians.length === 7 ? "Fully Protected" : guardians.length >= 4 ? "Protected" : "Action Required"}</p>
                            </div>
                        </div>
                        <button
                            onClick={() => setShowGuardianManager(true)}
                            className="text-[10px] font-bold text-primary px-3 py-1.5 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
                        >
                            {guardians.length > 0 ? "Edit Guardians" : "Set Up Recovery"}
                        </button>
                    </div>
                    <div className="flex items-center space-x-2">
                        <div className="flex -space-x-2">
                            {guardians.length > 0 ? (
                                guardians.slice(0, 3).map((g, i) => (
                                    <div key={i} className="w-6 h-6 rounded-full border-2 border-white bg-primary text-white flex items-center justify-center text-[8px] font-bold">
                                        {i + 1}
                                    </div>
                                ))
                            ) : (
                                [1, 2, 3].map(i => (
                                    <div key={i} className="w-6 h-6 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-[8px] font-bold text-secondary">
                                        ?
                                    </div>
                                ))
                            )}
                            {guardians.length > 3 && (
                                <div className="w-6 h-6 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-[8px] font-bold text-secondary">
                                    +{guardians.length - 3}
                                </div>
                            )}
                        </div>
                        <p className="text-[10px] text-secondary">
                            {guardians.length >= 4
                                ? `${guardians.length}/7 guardians active. Threshold met.`
                                : `${guardians.length}/7 guardians. Minimum 4 required for recovery.`}
                        </p>
                    </div>
                </div>

                {/* Guardian Manager Modal */}
                {showGuardianManager && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setShowGuardianManager(false)}></div>
                        <div className="relative w-full max-w-md animate-in zoom-in-95 duration-200">
                            <GuardianManager onClose={() => setShowGuardianManager(false)} />
                        </div>
                    </div>
                )}

                {/* Actions removed from here and moved to top */}
                <div className="h-4"></div>

                <div className="h-4"></div>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-gray-100 mb-2 overflow-x-auto no-scrollbar">
                {['feed', 'media', 'files', 'tweets'].map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab as Tab)}
                        className={`flex-1 py-3 text-sm font-medium capitalize relative ${activeTab === tab ? 'text-foreground' : 'text-secondary'}`}
                    >
                        {tab}
                        {activeTab === tab && (
                            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-8 h-1 bg-primary rounded-t-full" />
                        )}
                    </button>
                ))}
            </div>

            {/* Tab Content */}
            <div className="min-h-[300px]">
                {activeTab === 'feed' && (
                    <div className="pb-4">
                        {posts.map(post => (
                            <PostCard
                                key={post.cid}
                                item={post}
                                interactions={interactions[post.cid]}
                                onPostDeleted={(cid) => setPosts(prev => prev.filter(p => p.cid !== cid))}
                                onPostUpdated={(cid, newTitle, newDescription) => setPosts(prev => prev.map(p =>
                                    p.cid === cid ? { ...p, name: newTitle, description: newDescription } : p
                                ))}
                            />
                        ))}
                    </div>
                )}

                {activeTab === 'media' && (
                    <div className="animate-in fade-in duration-300">
                        {/* Sub-tabs for Media */}
                        <div className="flex px-4 py-3 space-x-6 border-b border-gray-50 mb-1 overflow-x-auto no-scrollbar">
                            {(['all', 'images', 'videos'] as MediaSubTab[]).map(tab => (
                                <button
                                    key={tab}
                                    onClick={() => setMediaSubTab(tab)}
                                    className={`text-xs font-bold uppercase tracking-wider transition-colors ${mediaSubTab === tab ? 'text-primary' : 'text-secondary hover:text-foreground'}`}
                                >
                                    {tab}
                                </button>
                            ))}
                        </div>

                        <div className="grid grid-cols-3 gap-0.5">
                            {mediaPosts.map((post, i) => (
                                <div key={i} className="aspect-square bg-gray-100 relative overflow-hidden group">
                                    <Link href={`/post/${post.cid}`}>
                                        {post.filename.toLowerCase().endsWith('.mp4') ? (
                                            <video src={`http://localhost:8080/ipfs/${post.cid}`} className="w-full h-full object-cover" />
                                        ) : (
                                            <img src={`http://localhost:8080/ipfs/${post.cid}`} alt={post.name} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                                        )}
                                        {post.filename.toLowerCase().endsWith('.mp4') && (
                                            <div className="absolute top-2 right-2 p-1 bg-black/40 rounded text-white text-[8px] font-bold">VIDEO</div>
                                        )}
                                    </Link>
                                </div>
                            ))}
                            {/* Placeholder items to fill grid if empty */}
                            {mediaPosts.length === 0 && Array.from({ length: 9 }).map((_, i) => (
                                <div key={i} className="aspect-square bg-gray-50 shimmer"></div>
                            ))}
                        </div>
                    </div>
                )}

                {activeTab === 'files' && (
                    <div className="px-4 py-2 space-y-3">
                        {filePosts.map((file, i) => (
                            <div key={i} className="flex items-center p-3 border border-gray-100 rounded-xl hover:bg-gray-50 bg-white shadow-sm">
                                <div className="w-10 h-10 rounded-lg bg-orange-100 text-orange-500 flex items-center justify-center text-xl mr-3">
                                    📄
                                </div>
                                <div className="flex-1 min-w-0">
                                    <h3 className="text-sm font-medium text-foreground truncate">{file.name}</h3>
                                    <p className="text-xs text-secondary">{file.timestamp?.split(' ')[0]} • {file.type}</p>
                                </div>
                                <a href={`http://localhost:8080/ipfs/${file.cid}`} target="_blank" className="text-secondary hover:text-primary p-2">
                                    <FaShare />
                                </a>
                            </div>
                        ))}
                        {filePosts.length === 0 && (
                            <div className="text-center py-10 text-secondary text-sm">No files shared yet</div>
                        )}
                    </div>
                )}

                {activeTab === 'tweets' && (
                    <div className="flex flex-col items-center justify-center py-12 text-secondary">
                        <p>No tweets yet</p>
                    </div>
                )}
                {(activeTab === 'syncs' || activeTab === 'contacts') && (
                    <div className="px-4 py-6 space-y-6">
                        <div className="flex items-center justify-between mb-2">
                            <h2 className="text-xl font-bold text-foreground capitalize">{activeTab}</h2>
                            <button
                                onClick={async () => {
                                    setIsSyncing(true);
                                    try {
                                        const res = await fetch('http://localhost:8000/api/sync-peers', { method: 'POST' });
                                        if (res.ok) {
                                            const data = await res.json();
                                            alert(`Successfully synced ${data.synced_peers} peer(s)`);
                                            const followRes = await fetch('http://localhost:8000/api/following');
                                            const followData = await followRes.json();
                                            setFollowing(followData.following || []);
                                        }
                                    } finally {
                                        setIsSyncing(false);
                                    }
                                }}
                                disabled={isSyncing}
                                className="flex items-center space-x-2 px-4 py-2 bg-purple-50 text-primary rounded-xl text-sm font-bold hover:bg-purple-100 transition-all disabled:opacity-50"
                            >
                                <FaArrowsRotate className={isSyncing ? 'animate-spin' : ''} />
                                <span>Sync All</span>
                            </button>
                        </div>

                        {following.filter(f => activeTab === 'syncs' ? f.relationship_type === 'sync' : f.relationship_type === 'contact').length === 0 ? (
                            <div className="text-center py-20 bg-gray-50 rounded-3xl border border-dashed border-gray-200">
                                <p className="text-secondary font-medium">No {activeTab} yet</p>
                                <Link href="/qr-scan" className="mt-4 inline-flex items-center space-x-2 text-primary font-bold text-sm">
                                    <span>Find Peers</span>
                                </Link>
                            </div>
                        ) : (
                            <div className="grid gap-4">
                                {following
                                    .filter(f => activeTab === 'syncs' ? f.relationship_type === 'sync' : f.relationship_type === 'contact')
                                    .map((peer) => (
                                        <div key={peer.peer_id} className="bg-white p-5 rounded-3xl border border-gray-100 hover:border-primary/20 hover:shadow-md transition-all group">
                                            <div className="flex items-start justify-between">
                                                <div className="flex space-x-4">
                                                    <Avatar
                                                        src={peer.avatar}
                                                        seed={peer.peer_id}
                                                        size="md"
                                                        className="w-12 h-12 !rounded-2xl group-hover:scale-110 transition-transform"
                                                    />
                                                    <div className="flex-1 min-w-0">
                                                        <h3 className="font-bold text-base text-foreground group-hover:text-primary transition-colors">{peer.username}</h3>
                                                        <p className="text-[10px] text-secondary font-mono mt-0.5 break-all opacity-60">
                                                            {peer.peer_id}
                                                        </p>
                                                        <div className="mt-3 flex items-center space-x-4 text-[10px] text-gray-500 font-medium uppercase tracking-wider">
                                                            <div className="flex items-center space-x-1.5">
                                                                <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                                                                <span>Last: {peer.last_synced ? new Date(peer.last_synced).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Never'}</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="flex flex-col gap-2">
                                                    <Link
                                                        href={`/messages/${peer.peer_id}`}
                                                        className="px-3 py-1.5 text-[11px] font-bold text-primary bg-purple-50 hover:bg-primary hover:text-white rounded-lg transition-all text-center"
                                                    >
                                                        Message
                                                    </Link>
                                                    <button
                                                        onClick={async () => {
                                                            if (!confirm(`Stop syncing with ${peer.username}?`)) return;
                                                            const res = await fetch(`http://localhost:8000/api/unfollow/${peer.peer_id}`, { method: 'POST' });
                                                            if (res.ok) {
                                                                const followRes = await fetch('http://localhost:8000/api/following');
                                                                const followData = await followRes.json();
                                                                setFollowing(followData.following || []);
                                                            }
                                                        }}
                                                        className="px-3 py-1.5 text-[11px] font-bold text-secondary hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                                    >
                                                        Unsync
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                            </div>
                        )}

                        <div className="pt-4">
                            <Link href="/qr-scan" className="w-full h-14 border-2 border-dashed border-gray-100 rounded-2xl flex items-center justify-center space-x-2 text-secondary hover:text-primary hover:border-primary/30 transition-all text-sm font-bold">
                                <span>+ Add New Peer</span>
                            </Link>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
