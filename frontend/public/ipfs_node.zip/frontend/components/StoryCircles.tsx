import React from 'react';
import Link from 'next/link';
import { FaPlus } from 'react-icons/fa6';
import { LibraryItem } from '../lib/api';
import Avatar from './Avatar';

interface StoryCirclesProps {
    library: LibraryItem[];
}

const StoryCircles = ({ library }: StoryCirclesProps) => {
    // Get unique authors
    const uniqueAuthors = React.useMemo(() => {
        const authors = new Map<string, string>();
        library.forEach((item) => {
            if (!authors.has(item.author)) {
                authors.set(item.author, item.avatar);
            }
        });
        return Array.from(authors.entries()).slice(0, 10);
    }, [library]);

    return (
        <div className="w-full overflow-x-auto scrollbar-hide py-4 px-4 bg-background border-b border-gray-100">
            <div className="flex space-x-4 min-w-max">
                {/* Ad story button */}
                <Link href="/services" className="flex flex-col items-center space-y-1">
                    <div className="w-16 h-16 rounded-full p-[2px] border-2 border-gray-200">
                        <div className="w-full h-full rounded-full bg-gray-50 flex items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors">
                            <FaPlus className="text-primary text-xl" />
                        </div>
                    </div>
                    <span className="text-xs font-medium text-secondary">Add Story</span>
                </Link>

                {uniqueAuthors.map(([author, avatar]) => (
                    <Link
                        key={author}
                        href={`/feed?author=${author}`}
                        className="flex flex-col items-center space-y-1.5 hover:opacity-80 transition-opacity"
                    >
                        <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-to-tr from-primary via-purple-500 to-blue-500 shadow-md">
                            <div className="w-full h-full rounded-full bg-white p-[2px]">
                                <Avatar
                                    src={avatar}
                                    seed={author}
                                    size="lg"
                                    className="!w-full !h-full border-none shadow-none"
                                />
                            </div>
                        </div>
                        <span className="text-[10px] font-bold text-gray-700 truncate w-16 text-center tracking-tight">
                            {author}
                        </span>
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default StoryCircles;
