"use client";

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';

export default function AuthGuard({ children }: { children: React.ReactNode }) {
    const router = useRouter();
    const pathname = usePathname();
    const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

    useEffect(() => {
        const checkAuth = () => {
            const did = localStorage.getItem('ipfs_did');
            const auth = localStorage.getItem('isAuthenticated') === 'true';

            if (did && auth) {
                setIsAuthenticated(true);
            } else {
                setIsAuthenticated(false);
                if (pathname !== '/login' && pathname !== '/recover') {
                    router.push('/login');
                }
            }
        };

        checkAuth();

        // Listen for storage changes (e.g., if user clears storage)
        window.addEventListener('storage', checkAuth);
        return () => window.removeEventListener('storage', checkAuth);
    }, [pathname, router]);

    // Show nothing or a loader while checking
    if (isAuthenticated === null) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-white">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
        );
    }

    return <>{children}</>;
}
