"use client";

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { FaRegBell, FaHouse, FaUser, FaMessage, FaRss, FaCube, FaHeart, FaGear, FaArrowRightFromBracket, FaChevronDown } from 'react-icons/fa6';
import { logout } from '../lib/api';
import { useState, useRef, useEffect } from 'react';

const TopBar = () => {
    const pathname = usePathname();
    const [showUserMenu, setShowUserMenu] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    // Close menu when clicking outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setShowUserMenu(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const navItems = [
        { label: 'Home', icon: <FaHouse />, href: '/' },
        { label: 'Feed', icon: <FaRss />, href: '/feed' },
        { label: 'Services', icon: <FaCube />, href: '/services' },
        { label: 'Recommended', icon: <FaHeart />, href: '/recommended' },
        { label: 'Profile', icon: <FaUser />, href: '/profile' },
    ];

    return (
        <div className="fixed top-0 left-0 right-0 h-16 md:h-16 bg-white/90 backdrop-blur-md border-b border-gray-200 z-50 max-w-7xl mx-auto">
            <div className="flex items-center justify-between h-full px-4 md:px-8">
                {/* Logo */}
                <Link href="/" className="font-bold text-xl text-primary tracking-tight">
                    bucks
                </Link>

                {/* Desktop Navigation */}
                <nav className="hidden md:flex items-center space-x-1">
                    {navItems.map((item) => {
                        const isActive = pathname === item.href;
                        return (
                            <Link
                                key={item.href}
                                href={item.href}
                                className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${isActive
                                    ? 'bg-primary/10 text-primary'
                                    : 'text-secondary hover:bg-gray-100 hover:text-foreground'
                                    }`}
                            >
                                <span className="text-base flex items-center">{item.icon}</span>
                                <span>{item.label}</span>
                            </Link>
                        );
                    })}
                </nav>

                {/* Right side */}
                <div className="flex items-center space-x-2 md:space-x-4">
                    <Link href="/messages" className="hidden sm:flex w-10 h-10 rounded-full items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors relative group">
                        <FaMessage className="text-lg text-foreground group-hover:text-primary transition-colors" />
                        <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
                    </Link>
                    <div className="hidden sm:flex w-10 h-10 rounded-full items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors group">
                        <FaRegBell className="text-lg text-foreground group-hover:text-primary transition-colors" />
                    </div>

                    {/* User Menu Dropdown */}
                    <div className="relative" ref={menuRef}>
                        <button
                            onClick={() => setShowUserMenu(!showUserMenu)}
                            className="flex items-center space-x-2 p-1 pl-1 pr-3 border border-gray-200 rounded-full hover:shadow-md transition-shadow bg-white group"
                        >
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold overflow-hidden transition-colors group-hover:bg-primary/20">
                                <FaUser className="text-xs" />
                            </div>
                            <FaChevronDown className={`text-[10px] text-gray-500 transition-transform ${showUserMenu ? 'rotate-180' : ''}`} />
                        </button>

                        {showUserMenu && (
                            <div className="absolute right-0 mt-2 w-56 bg-white border border-gray-200 rounded-2xl shadow-xl py-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                                <Link
                                    href="/settings"
                                    onClick={() => setShowUserMenu(false)}
                                    className="flex items-center space-x-3 px-4 py-3 hover:bg-gray-50 transition-colors text-gray-700"
                                >
                                    <FaGear className="text-gray-400" />
                                    <div className="flex flex-col">
                                        <span className="text-sm font-semibold">Settings</span>
                                        <span className="text-[10px] text-gray-400 leading-tight">Profile & Preferences</span>
                                    </div>
                                </Link>
                                <div className="h-px bg-gray-100 my-1 mx-2"></div>
                                <button
                                    onClick={() => {
                                        setShowUserMenu(false);
                                        logout();
                                    }}
                                    className="w-full flex items-center space-x-3 px-4 py-3 hover:bg-red-50 transition-colors text-red-600"
                                >
                                    <FaArrowRightFromBracket />
                                    <span className="text-sm font-semibold">Logout</span>
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TopBar;
