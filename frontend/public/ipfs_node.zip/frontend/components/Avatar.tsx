"use client";

import React from 'react';

interface AvatarProps {
    src?: string;
    seed?: string; // Peer ID or username to generate deterministic pattern
    size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
    className?: string;
}

const Avatar: React.FC<AvatarProps> = ({ src, seed = 'anonymous', size = 'md', className = '' }) => {
    const sizeMap = {
        'xs': 'w-6 h-6 text-[8px]',
        'sm': 'w-8 h-8 text-[10px]',
        'md': 'w-10 h-10 text-xs',
        'lg': 'w-14 h-14 text-sm',
        'xl': 'w-20 h-20 text-base',
    };

    if (src && src !== 'ipfs://' && !src.includes('broken')) {
        return (
            <div className={`${sizeMap[size]} rounded-full overflow-hidden border border-white/10 shadow-inner flex-shrink-0 ${className}`}>
                <img
                    src={src.startsWith('http') ? src : `http://localhost:8080/ipfs/${src.replace('ipfs://', '')}`}
                    alt="avatar"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                    }}
                />
            </div>
        );
    }

    // Generate deterministic background color and pattern
    const getHash = (str: string) => {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        return hash;
    };

    const hash = getHash(seed);
    const hue = Math.abs(hash % 360);
    const bgColor = `hsl(${hue}, 60%, 40%)`;
    const accentColor = `hsl(${(hue + 40) % 360}, 70%, 60%)`;

    return (
        <div
            className={`${sizeMap[size]} rounded-full flex-shrink-0 flex items-center justify-center text-white font-bold relative overflow-hidden shadow-lg ${className}`}
            style={{ backgroundColor: bgColor }}
        >
            {/* Deterministic Geometric Pattern */}
            <svg className="absolute inset-0 w-full h-full opacity-30" viewBox="0 0 100 100" preserveAspectRatio="none">
                <rect x="0" y="0" width="50" height="50" fill={accentColor} transform={`rotate(${hash % 90} 50 50)`} />
                <circle cx="100" cy="100" r="40" fill={accentColor} />
                <path d="M0 100 L50 0 L100 100 Z" fill={accentColor} />
            </svg>
            <span className="relative z-10 uppercase">
                {seed.substring(0, 2)}
            </span>
        </div>
    );
};

export default Avatar;
