"use client";

import React, { useState } from 'react';
import { FaTrash, FaUser } from 'react-icons/fa6';
import { addComment, deleteComment } from '../lib/api';

interface CommentsProps {
    cid: string;
    comments: string[];
    onCommentAdded: () => void;
}

const Comments = ({ cid, comments, onCommentAdded }: CommentsProps) => {
    const [newComment, setNewComment] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newComment.trim()) return;

        setIsSubmitting(true);
        try {
            await addComment(cid, newComment);
            setNewComment('');
            onCommentAdded();
        } catch (error) {
            console.error('Failed to add comment', error);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDelete = async (index: number) => {
        if (!confirm('Are you sure you want to delete this comment?')) return;
        try {
            await deleteComment(cid, index);
            onCommentAdded();
        } catch (error) {
            console.error('Failed to delete comment', error);
        }
    };

    return (
        <div className="bg-gray-50 p-4 border-t border-gray-100 animate-fade-in">
            <div className="space-y-4 mb-4">
                {comments.map((comment, index) => (
                    <div key={index} className="flex space-x-3">
                        <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0">
                            <FaUser className="text-gray-400 text-sm" />
                        </div>
                        <div className="flex-1 bg-white p-3 rounded-2xl rounded-tl-none shadow-sm text-sm">
                            <div className="flex justify-between items-start">
                                <span className="font-semibold text-xs text-foreground mb-1 block">User</span>
                                <button
                                    onClick={() => handleDelete(index)}
                                    className="text-gray-400 hover:text-red-500 transition-colors"
                                >
                                    <FaTrash className="text-xs" />
                                </button>
                            </div>
                            <p className="text-secondary">{comment}</p>
                        </div>
                    </div>
                ))}
                {comments.length === 0 && (
                    <p className="text-center text-sm text-gray-400 py-2">No comments yet. Be the first!</p>
                )}
            </div>

            <form onSubmit={handleSubmit} className="flex space-x-2">
                <input
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment..."
                    className="flex-1 px-4 py-2 rounded-full border border-gray-200 focus:outline-none focus:border-primary text-sm bg-white"
                    disabled={isSubmitting}
                />
                <button
                    type="submit"
                    className="px-4 py-2 bg-primary text-white rounded-full text-sm font-medium hover:bg-purple-700 transition-colors disabled:opacity-50"
                    disabled={isSubmitting || !newComment.trim()}
                >
                    Post
                </button>
            </form>
        </div>
    );
};

export default Comments;
