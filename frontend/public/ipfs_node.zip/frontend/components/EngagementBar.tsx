"use client";

import React, { useState } from 'react';
import { FaArrowUp, FaArrowDown, FaRegComment, FaShare } from 'react-icons/fa6';
import { toggleLike, toggleDislike } from '../lib/api';

interface EngagementBarProps {
    cid: string;
    initialRecommended: boolean;
    initialNotRecommended: boolean;
    commentsCount: number;
    onCommentClick: () => void;
}

const EngagementBar = ({
    cid,
    initialRecommended,
    initialNotRecommended,
    commentsCount,
    onCommentClick
}: EngagementBarProps) => {
    const [recommended, setRecommended] = useState(initialRecommended);
    const [notRecommended, setNotRecommended] = useState(initialNotRecommended);
    const [likesCount, setLikesCount] = useState(initialRecommended ? 33 : 32);
    const [dislikesCount, setDislikesCount] = useState(initialNotRecommended ? 5 : 4);

    const handleLike = async () => {
        // Optimistic update
        const newRecommended = !recommended;
        setRecommended(newRecommended);
        setLikesCount(prev => newRecommended ? prev + 1 : prev - 1);

        if (newRecommended && notRecommended) {
            setNotRecommended(false);
            setDislikesCount(prev => prev - 1);
        }

        try {
            await toggleLike(cid);
        } catch (error) {
            // Revert on error
            console.error('Failed to like', error);
            setRecommended(!newRecommended);
            setLikesCount(prev => !newRecommended ? prev + 1 : prev - 1);
        }
    };

    const handleDislike = async () => {
        const newNotRecommended = !notRecommended;
        setNotRecommended(newNotRecommended);
        setDislikesCount(prev => newNotRecommended ? prev + 1 : prev - 1);

        if (newNotRecommended && recommended) {
            setRecommended(false);
            setLikesCount(prev => prev - 1);
        }

        try {
            await toggleDislike(cid);
        } catch (error) {
            console.error('Failed to dislike', error);
            setNotRecommended(!newNotRecommended);
            setDislikesCount(prev => !newNotRecommended ? prev + 1 : prev - 1);
        }
    };

    return (
        <div className="flex items-center justify-between py-3 border-t border-gray-100 mt-3 px-2">
            <div className="flex items-center space-x-1">
                <button
                    onClick={handleLike}
                    className={`flex items-center space-x-1 px-3 py-1.5 rounded-full transition-colors ${recommended ? 'bg-green-100 text-green-600' : 'hover:bg-gray-100 text-secondary'
                        }`}
                >
                    <FaArrowUp />
                    <span className="text-sm font-medium">{likesCount}</span>
                </button>

                <button
                    onClick={handleDislike}
                    className={`flex items-center space-x-1 px-3 py-1.5 rounded-full transition-colors ${notRecommended ? 'bg-red-100 text-red-600' : 'hover:bg-gray-100 text-secondary'
                        }`}
                >
                    <FaArrowDown />
                    <span className="text-sm font-medium">{dislikesCount}</span>
                </button>
            </div>

            <button
                onClick={onCommentClick}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-full hover:bg-gray-100 text-secondary transition-colors"
            >
                <FaRegComment />
                <span className="text-sm font-medium">{commentsCount}</span>
            </button>

            <button className="flex items-center space-x-1 px-3 py-1.5 rounded-full hover:bg-gray-100 text-secondary transition-colors">
                <FaShare />
            </button>
        </div>
    );
};

export default EngagementBar;
