import axios from 'axios';

// API Client configuration
export const api = axios.create({
    baseURL: 'http://localhost:8000/api',
    headers: {
        'Content-Type': 'application/json',
    },
});

export interface LibraryItem {
    cid: string;
    thumbnail_cid?: string;
    name: string;
    description: string;
    filename: string;
    type: string;
    author: string;
    avatar: string;
    timestamp: string;
    recommended_by?: string[];
    _is_social_discovery?: boolean;
}

export interface Interaction {
    recommended: boolean;
    not_recommended: boolean;
    comments: string[];
    views: number;
}

export interface UserProfile {
    username: string;
    handle?: string;
    avatar: string;
    banner?: string;
    bio: string;
    location?: string;
    tags?: string[];
    peer_id?: string;
    stats: {
        syncs: number;
        contacts: number;
        posts?: number;
        likes?: number;
    };
}

export const fetchLibrary = async () => {
    const response = await api.get<{ library: LibraryItem[] }>('/library');
    return response.data.library;
};

export const fetchPost = async (cid: string) => {
    const response = await api.get<LibraryItem>(`/library/${cid}`);
    return response.data;
};

export const fetchInteractions = async (cid: string) => {
    const response = await api.get<Interaction>(`/interactions/${cid}`);
    return response.data;
};

export const fetchAllInteractions = async () => {
    const response = await api.get<Record<string, Interaction>>('/interactions');
    return response.data;
};

export const toggleLike = async (cid: string) => {
    const response = await api.post<Interaction>(`/interactions/${cid}/like`);
    return response.data;
};

export const toggleDislike = async (cid: string) => {
    const response = await api.post<Interaction>(`/interactions/${cid}/dislike`);
    return response.data;
};

export const addComment = async (cid: string, text: string) => {
    const response = await api.post<{ success: boolean; comment: string }>(`/interactions/${cid}/comment`, { text });
    return response.data;
};

export const deleteComment = async (cid: string, index: number) => {
    const response = await api.delete<{ success: boolean }>(`/interactions/${cid}/comment/${index}`);
    return response.data;
};

export const uploadFile = async (formData: FormData) => {
    const response = await api.post<{ cid: string; filename: string; success: boolean }>('/upload', formData, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    });
    return response.data;
};

export const fetchProfile = async () => {
    const response = await api.get<UserProfile>('/profile');
    return response.data;
};

export const deletePost = async (cid: string) => {
    const response = await api.delete<{ success: boolean; message: string }>(`/library/${cid}`);
    return response.data;
};

export const updatePost = async (cid: string, title: string, description: string) => {
    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description);
    const response = await api.put<{ success: boolean; post: LibraryItem }>(`/library/${cid}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
};

export const updateProfile = async (data: {
    username?: string;
    handle?: string;
    bio?: string;
    location?: string;
    avatar?: string;
    banner?: string;
}) => {
    const formData = new FormData();
    if (data.username) formData.append('username', data.username);
    if (data.handle) formData.append('handle', data.handle);
    if (data.bio) formData.append('bio', data.bio);
    if (data.location) formData.append('location', data.location);
    if (data.avatar) formData.append('avatar', data.avatar);
    if (data.banner) formData.append('banner', data.banner);

    const response = await api.post<{ success: boolean; profile: UserProfile }>('/profile', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
};

/**
 * Logout: Clear local identity and redirect to login
 */
export const logout = () => {
    if (typeof window !== 'undefined') {
        localStorage.removeItem('bucks_identity');
        localStorage.removeItem('bucks_peer_id');
        // Clear anything else relevant
        window.location.href = '/login';
    }
};

export const fetchFollowing = async () => {
    const response = await api.get<any[]>('/following');
    return response.data;
};

export const getIPFSUrl = (cid: string) => `http://localhost:8080/ipfs/${cid}`;

export default api;
