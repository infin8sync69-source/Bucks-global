#!/bin/bash

# Kill ports 8000 and 3000 just in case
lsof -ti:8000 | xargs kill -9 2>/dev/null
lsof -ti:3000 | xargs kill -9 2>/dev/null

# Start IPFS Daemon (if not already running)
IPFS_BIN="$(dirname "$0")/bin/ipfs"
if ! lsof -i :5001 >/dev/null 2>&1; then
    echo "Starting IPFS Daemon..."
    "$IPFS_BIN" daemon &
    IPFS_PID=$!
    sleep 2
    echo "Bootstrapping to primary peer..."
    "$IPFS_BIN" bootstrap add /ip4/127.0.0.1/tcp/4001/p2p/12D3KooWAZ83vBQhEuxPBnVQJ9NtvWC11zce14FSdDH2kT1241PT
    "$IPFS_BIN" config show | grep "/p2p/"| head -n 1
    sleep 3  # Wait for daemon to initialize
    echo "IPFS Gateway: http://localhost:8080"
else
    echo "IPFS Daemon already running."
    IPFS_PID=""
fi

# Start Backend
echo "Starting Backend..."
# Activate venv
source venv/bin/activate
# Install dependencies if needed
pip install -r backend/requirements.txt
cd backend
python3 -m uvicorn main:app --reload --port 8000 &
BACKEND_PID=$!
cd ..

# Start Frontend
echo "Starting Frontend..."
cd frontend
export PATH="/opt/homebrew/bin:$PATH"
npm run dev &
FRONTEND_PID=$!
cd ..

echo "App running!"
echo "Backend: http://localhost:8000"
echo "Frontend: http://localhost:3000"
echo "Press CTRL+C to stop both."

wait $BACKEND_PID $FRONTEND_PID
